import React from 'react'



export default function Productos() {
    return (
        <>
  
             <h1>Productos</h1>
      
          
     
       
       
       
       </>
 
    );
  }
  