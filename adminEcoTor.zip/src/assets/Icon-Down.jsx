// MyIcon.jsx
const IconDown = () => (
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="17" viewBox="0 0 16 17" fill="none">
  <path d="M13 6.83252L8 11.8325L3 6.83252" stroke="#98A2B3" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
  );
  export default IconDown;